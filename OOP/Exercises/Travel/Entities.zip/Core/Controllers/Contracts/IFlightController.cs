﻿namespace Travel.Core.Controllers.Contracts
{
	public interface IFlightController
	{
		string TakeOff();
	}
}